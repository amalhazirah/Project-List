CREATE TABLE Flower (
FlowerCode VARCHAR(10) PRIMARY KEY,
FlowerName VARCHAR(50) NOT NULL,
FlowerAvailability ENUM('Yes', 'No') NOT NULL,
stockInventory INT,
Price DECIMAL(9,2),
SupplierId VARCHAR(15),
FOREIGN KEY (SupplierId) REFERENCES Supplier(SupplierId));

SELECT*FROM Flower;