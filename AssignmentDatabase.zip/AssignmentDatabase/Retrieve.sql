SELECT * FROM staff;

SELECT SupplierId, SupplierName
FROM Supplier;

SELECT O.orderId, S.staffName
FROM OrderInformation O
JOIN Staff S ON S.StaffId = O.staffId;

SELECT O.ICNumber, O.OrderId, o.price
FROM OrderInformation O
JOIN Payment p ON p.PaymentId = O.PaymentId
WHERE p.paymentStatus ='No' AND p.paymentType ='Visa';