CREATE TABLE OrderInformation (
OrderId VARCHAR(15) PRIMARY KEY,
ICNumber VARCHAR(50) NOT NULL,
quantity INT,
price DECIMAL(9,2),
PaymentId VARCHAR(15),
StaffId VARCHAR(15),
FOREIGN KEY (StaffId) REFERENCES Staff(StaffId),
FOREIGN KEY (PaymentId) REFERENCES Payment(PaymentId),
FOREIGN KEY (ICNumber) REFERENCES Customer(ICNumber));

SELECT*FROM OrderInformation;
