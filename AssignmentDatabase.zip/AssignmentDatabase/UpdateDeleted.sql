UPDATE Customer SET PhoneNumber = '011-59056410' 
WHERE ICNumber = '990615-10-8590';

UPDATE Flower SET stockInventory = 60
WHERE FlowerCode = 'HIJ34';

UPDATE Payment SET paymentStatus ='Yes'
WHERE PaymentId = 'TRX-026-7B';

DELETE FROM Staff WHERE staffId='ST002';

SELECT*FROM staff;