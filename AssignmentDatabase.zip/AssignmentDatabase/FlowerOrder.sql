CREATE TABLE FlowerOrder (
OrderId VARCHAR(15),
FlowerCode VARCHAR(10),
FOREIGN KEY (OrderId) REFERENCES OrderInformation(OrderId),
FOREIGN KEY (FlowerCode) REFERENCES Flower(FlowerCode));

SELECT*FROM FlowerOrder;