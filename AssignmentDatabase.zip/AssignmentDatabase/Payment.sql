CREATE TABLE Payment (
PaymentId VARCHAR(15) PRIMARY KEY,
PaymentType VARCHAR(255) NOT NULL
CHECK (PaymentType IN ('Visa','Cash','Online Transaction','Ewallet')),
PaymentStatus ENUM('Yes', 'No') NOT NULL);

SELECT*FROM Payment;